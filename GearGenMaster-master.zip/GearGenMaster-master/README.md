# GearGenMaster

## Gear generator for Blender

Use `Add / Mesh / GearGenMaster` menu item to add new gear.

Supported gear types:

 * internal / external spur gear;
 * bevel gear;
 * worm gear.
